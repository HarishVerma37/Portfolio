
import { Link, NavLink } from "react-router-dom";
import "./Navbar.css"
export default function Navbar() {

    return (
        <div className="containern">
            <div className="navbar">
                <NavLink to="/" className="navbar-brand">Harish</NavLink>

                <div className="navbar-nav">
                    <NavLink to="/Skills">Skills</NavLink>
                    <NavLink to="/projects">Projects</NavLink>
                    <NavLink to="/About">About</NavLink>
                    <NavLink to="/contactMe">ContactMe</NavLink>
                </div>
            </div>
        </div>
    );
}