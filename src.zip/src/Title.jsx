import "./Title.css"
export default function Title({Title}){
   
    return(
        <h4 className="Title">{Title}</h4>
    )
}